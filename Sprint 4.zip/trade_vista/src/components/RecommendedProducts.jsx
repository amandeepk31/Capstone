import React, { useEffect, useState } from "react";
import axios from 'axios';
import { ProductElement } from "../components";

const RecommendedProducts = () => {
    const [products, setProducts] = useState([]);
    const getProducts = async () => {
        const response = await axios(
            `http://localhost:8080/products`
        );
        setProducts(response.data.sort(() => Math.random() - 0.5).slice(0, 4));
    };

useEffect(() => {
    getProducts()
  }, []);

  return (
    <div className="product-reviews max-w-7xl mt-10 mx-auto">
      <div className="product-reviews-comments mt-20 px-10">
        <h2 className="text-4xl text-accent-content text-center mb-5 max-sm:text-2xl">
          Recommended Products
        </h2>

        <div className="selected-products-grid max-w-7xl mx-auto">
          {products.map((product) => (
            <ProductElement
              key={product.id}
              id={product.id}
              title={product.name}
              image={product.imageUrl}
              rating={product.rating}
              price={product.price.current.value}
            />
          ))}
        </div>

      </div>
    </div>
  );
};

export default RecommendedProducts;
