const FormSelect = ({ label, name, list, defaultValue, size }) => {
    return (
      <div className='form-control'>
        <label htmlFor={name} className='label'>
          <span className='label-text capitalize'>{label}</span>
        </label>
        <select
          name={name}
          id={name}
          className={`select select-bordered ${size}`}
          defaultValue={defaultValue}
        >
          <option value="all">
            all
          </option>
          {list.map((item) => {
            return (
              <option key={item.id} value={item.name}>
                {item.name}
              </option>
            );
          })}
        </select>
      </div>
    );
  };
  export default FormSelect;
  