import React, { useState, useEffect } from "react";
import FormInput from "./FormInput";
import { Form, Link } from "react-router-dom";
import FormRange from "./FormRange";
import FormSelect from "./FormSelect";
import FormDatePicker from "./FormDatePicker";
import FormCheckbox from "./FormCheckbox";
import axios from 'axios';

const Filters = () => {
  const [selectCategoryList, setSelectCategoryList] = useState([]);
  const [selectBrandList, setSelectBrandList] = useState([]);

  const fetchCategories = () => {
    axios.get('http://localhost:8080/categories')
      .then((response) => {
        setSelectCategoryList(response.data);
      })
      .catch((error) => {
        console.error('Error fetching categories:', error);
        toast.error('Error fetching categories: ', error);
      });
  };

  const fetchBrands = () => {
    axios.get('http://localhost:8080/brands')
      .then((response) => {
        setSelectBrandList(response.data);
      })
      .catch((error) => {
        console.error('Error fetching brands:', error);
        toast.error('Error fetching brands: ', error);
      });
  };

  useEffect(() => {
    fetchBrands();
    fetchCategories();
  }, []);

  return (
    <Form className="bg-base-200 rounded-md px-8 py-4 grid gap-x-4  gap-y-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 items-center">
      {/* SEARCH */}
      <FormInput
        type="search"
        label="search product"
        name="search"
        size="input-sm"
        defaultValue=""
      />
      {/* CATEGORIES */}
      <FormSelect
        label="select category"
        name="category"
        list={selectCategoryList}
        size="select-sm"
        defaultValue="all"
      />
      {/* COMPANIES */}
      <FormSelect
        label="select brand"
        name="brand"
        list={selectBrandList}
        size="select-sm"
        defaultValue="all"
      />
      {/* ORDER */}
      <FormSelect
        label="sort by"
        name="order"
        list={[
          { id:1, name: "asc", },
          { id:2, name: "desc", },
          { id:3, name: "priceHigh", },
          { id:4, name: "priceLow", },
        ]}
        size="select-sm"
        defaultValue="a-z"
      />
      {/* Producer */}
      <FormSelect
        label="Select gender"
        name="gender"
        list={
          [
          { id:1, name: "all", },
          { id:2, name: "male", },
          { id:3, name: "female", },
        ]}
        size="select-sm"
        defaultValue="all"
      />
      {/* PRICE */}
      <FormRange
        name="price"
        label="select price"
        size="range-sm"
        price={300}
      />
      {/* Date Picker */}
      {/* <FormDatePicker label="select minimum production date" name="date" /> */}

      {/* In stock */}
      {/* <FormCheckbox
        label="Only products in stock"
        name="stock"
        defaultValue="false"
      /> */}

      {/* BUTTONS */}

      <button
        type="submit"
        className="btn bg-blue-600 hover:bg-blue-500 text-white btn-sm"
      >
        search
      </button>
      <Link to="/shop?page=1" className="btn btn-primary btn-sm">
        reset
      </Link>
    </Form>
  );
};

export default Filters;
