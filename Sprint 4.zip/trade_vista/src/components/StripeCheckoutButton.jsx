import React, {useState} from "react";
import StripeCheckout from "react-stripe-checkout";
import { useNavigate } from "react-router-dom";
import { useSelector } from 'react-redux';

const style = {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'flex-end',
        width: '100%',
  };

const StripeCheckoutButton = () => {
  const navigate = useNavigate();
  const perishableKEY =
    "pk_test_51L9r9dGli9bvD6RjiIRS22iN6jqpeha7ktXyg1OYdu7CuLuyXJZOodI2a3F5u7RGRqoPNcA8wPECEpdatiFSTZOE00jx7yMSG5";
  const { total } = useSelector((state) => state.cart);
  const tax = total * 0.10;
  const shipping = 50;
  const priceForStripe = Math.round((total + shipping + tax) * 100);
  const onToken = (token) => {
    navigate("/thank-you");
  };

  return (
    <div style={style}>
      <StripeCheckout
        name="Trade Vista"
        ComponentClass="div"
        image="http://svgshare.com/i/CUz.svg"
        billingAddress
        shippingAddress
        description={`Your total is $${Math.round(total + shipping + tax)}`}
        amount={priceForStripe}
        panelLabel="Order Now" 
        label="Order Now"
        token={onToken}
        stripeKey={perishableKEY}
      ></StripeCheckout>
    </div>
  );
};

export default StripeCheckoutButton;
