import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

const initialState = {
  userId: localStorage.getItem('id') || false,
  role: localStorage.getItem('role') || 'user',
  username: localStorage.getItem('username') || '',
  isLoggedIn: localStorage.getItem('id') ? true : false,
  darkMode: true
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    loginUser: (state) => {
      state.isLoggedIn = true;
      state.userId = localStorage.getItem('id');
      state.role = localStorage.getItem('role');
      state.username = localStorage.getItem('username');
    },
    logoutUser: (state) => {
      state.isLoggedIn = false;
      state.userId = false;
      state.role = '';
      state.username = '';
      toast.success("You have successfuly logout");
    },
    changeMode: (state) => {
      state.darkMode = !state.darkMode;
      if(state.darkMode){
        document.querySelector('html').setAttribute('data-theme', "dark");
      }else{
        document.querySelector('html').setAttribute('data-theme', "winter");
      }
    }
  },
});

// console.log(cartSlice);
export const { loginUser, logoutUser, changeMode } = authSlice.actions;

export default authSlice.reducer;
