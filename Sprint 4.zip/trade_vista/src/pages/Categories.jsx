import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editCategoryName, setEditCategoryName] = useState('');
  const [editCategoryId, setEditCategoryId] = useState('');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = () => {
    axios.get('http://localhost:8080/categories')
      .then((response) => {
        setCategories(response.data);
      })
      .catch((error) => {
        console.error('Error fetching categories:', error);
        toast.error('Error fetching categories: ', error);
      });
  };

  const addCategory = () => {
    if (newCategoryName.trim() !== '') {
      axios.post('http://localhost:8080/categories', { name: newCategoryName })
        .then(() => {
          fetchCategories();
          setNewCategoryName('');
          toast.success('Category added successfully');
        })
        .catch((error) => {
          console.error('Error adding category:', error);
          toast.error('Error adding category: ', error);
        });
    }
  };

  const editCategory = () => {
    if (editCategoryName.trim() !== '') {
      axios.put(`http://localhost:8080/categories/${editCategoryId}`, { name: editCategoryName })
        .then(() => {
          fetchCategories();
          setEditCategoryName('');
          setEditCategoryId('');
          toast.success('Category updated successfully');
        })
        .catch((error) => {
          console.error('Error updating category:', error);
          toast.error('Error updating category: ', error);
        });
    }
  };

  const deleteCategory = (id) => {
    axios.delete(`http://localhost:8080/categories/${id}`)
      .then(() => {
        fetchCategories();
        toast.success('Category deleted');
      })
      .catch((error) => {
        console.error('Error deleting category:', error);
        toast.error('Error deleting category: ', error);
      });
  };

  const handleEdit = (id, name) => {
    setEditCategoryName(name);
    setEditCategoryId(id);
  };

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Categories</h2>
      </header>
      <div className="p-3">

        {/* Add Category */}
        <div className="mb-4">
          <input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="Enter new category name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
          <button
            onClick={addCategory}
            className="mt-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            Add Category
          </button>
        </div>

        {/* Search */}
        <div className="mb-4">
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search by category name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
        </div>

        {/* Edit Category */}
        {editCategoryId && (
          <div className="mb-4">
            <input
              type="text"
              value={editCategoryName}
              onChange={(e) => setEditCategoryName(e.target.value)}
              placeholder="Enter edited category name"
              className="px-3 py-2 border border-gray-300 rounded-md w-full"
            />
            <button
              onClick={editCategory}
              className="mt-2 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
            >
              Update Category
            </button>
          </div>
        )}

        {/* Categories Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">ID</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Name</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
              </tr>
            </thead>
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
              {
                filteredCategories.map((category, index) => (
                  <tr key={index}>
                    <td className="p-2 whitespace-nowrap">{index+1}</td>
                    <td className="p-2 whitespace-nowrap">{category.name}</td>
                    <td className="p-2 whitespace-nowrap">
                      <button
                        onClick={() => handleEdit(category.id, category.name)}
                        className="px-2 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 mr-2"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteCategory(category.id)}
                        className="px-2 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
