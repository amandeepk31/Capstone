import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";

export default function Reviews() {
  const [products, setProducts] = useState([]);
  const [searchText, setSearchText] = useState('');
  const navigate = useNavigate();
  
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = () => {
    axios.get('http://localhost:8080/products')
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        toast.error('Error fetching products: ', error);
      });
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleDeleteReview = async (product, username) => {
    const updatedReviews = product.reviews.filter((review) => review.username !== username);
    product.reviews = updatedReviews;
    try {
        await axios.put(`http://localhost:8080/products/${product.id}`, product);
        console.log('Review is deleted successfully', product);
        toast.success('Review is deleted successfully');
        fetchProducts();
        } catch (error) {
        console.error('Failed to delete review: ', error.message);
        toast.error('Failed to delete review');
        }
  };

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Reviews</h2>
        {/* Add Product Button */}
      </header>
      <div className="p-3">
        {/* Search */}
        <div className="mb-4">
          <input
            type="text"
            value={searchText}
            onChange={handleSearch}
            placeholder="Search by product name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            {/* Table header */}
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
               <tr>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Product Name</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Username</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Rating</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Date</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Review Title</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                    <div className="font-semibold text-left">Review Text</div>
                    </th>
                    <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
                </tr>
            </thead>
            {/* Table body */}
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
          {products.map(product => (
            product.reviews.map((review, index) => (
            <tr key={index}>
            <td className="p-2 whitespace-nowrap">
                <div className="text-left">{product.name}</div>
              </td>
              <td className="p-2 whitespace-nowrap">
                <div className="text-left">{review.username}</div>
              </td>
              <td className="p-2 whitespace-nowrap">
                <div className="text-left">{review.rating}</div>
              </td>
              <td className="p-2 whitespace-nowrap">
                <div className="text-left">{review.date}</div>
              </td>
              <td className="p-2 whitespace-nowrap">
                <div className="text-left">{review.reviewTitle}</div>
              </td>
              <td className="p-2 whitespace-nowrap">
                <div className="text-left">{review.reviewText}</div>
              </td>
              <td className="p-2 whitespace-nowrap">  
                    <button
                        onClick={() => handleDeleteReview(product, review.username)}
                        className="px-2 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                    >
                        Delete
                    </button>
                    </td>
            </tr>
          ))
          ))}
         
        </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
