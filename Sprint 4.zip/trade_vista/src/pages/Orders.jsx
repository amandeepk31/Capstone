import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [editedOrderId, setEditedOrderId] = useState('');
  const [editedOrderStatus, setEditedOrderStatus] = useState('');

  useEffect(() => {
    fetchOrders();
    fetchUsers();
  }, []);

  const fetchOrders = () => {
    axios.get('http://localhost:8080/orders')
      .then((response) => {
        setOrders(response.data);
      })
      .catch((error) => {
        console.error('Error fetching orders:', error);
        toast.error('Error fetching orders: ', error);
      });
  };

  const fetchUsers = () => {
    axios.get('http://localhost:8080/user')
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error('Error fetching users:', error);
        toast.error('Error fetching users: ', error);
      });
  };

  const findUserNameById = (userId) => {
    const foundUser = users.find(user => user.id === userId);
    return foundUser ? `${foundUser.name} ${foundUser.lastname}` : 'Unknown User';
  };

  const handleStatusChange = (order, newStatus) => {
    if(newStatus === ""){
        toast.error('Select the status');
        return;
    }
    order.orderStatus = newStatus;
    axios.put(`http://localhost:8080/orders/${order.id}`, order)
      .then(() => {
        fetchOrders();
        setEditedOrderId('');
        setEditedOrderStatus('');
        toast.success('Order status is updated');
      })
      .catch((error) => {
        console.error('Error updating order status:', error);
        toast.error('Error updating order status: ', error);
      });
  };

  const handleDeleteOrder = (orderId) => {
    axios.delete(`http://localhost:8080/orders/${orderId}`)
      .then(() => {
        fetchOrders();
        toast.success('Order deleted successfully');
      })
      .catch((error) => {
        console.error('Error deleting order:', error);
        toast.error('Error deleting order: ', error);
      });
  };

  const filteredOrders = orders.filter(order =>
    findUserNameById(order.userId).toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Orders</h2>
      </header>
      <div className="p-3">

        {/* Search */}
        <div className="mb-4">
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search by user name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            {/* Table header */}
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">User</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Status</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Total</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Cart Items</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
              </tr>
            </thead>
            {/* Table body */}
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
              {
                filteredOrders.map(order => (
                  <tr key={order.id}>
                    <td className="p-2 whitespace-nowrap">{findUserNameById(order.userId)}</td>
                    <td className="p-2 whitespace-nowrap">{order.orderStatus}</td>
                    <td className="p-2 whitespace-nowrap text-success">${(order.subtotal).toFixed(2)}</td>
                    <td className="p-2 whitespace-nowrap">{order.cartItems.length}</td>
                    <td className="p-2 whitespace-nowrap">
                      {editedOrderId !== order.id ? (
                        <button
                          onClick={() => setEditedOrderId(order.id)}
                          className="px-2 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 mr-2"
                        >
                          Edit Status
                        </button>
                      ) : (
                        <div>
                          <select
                            value={editedOrderStatus}
                            onChange={(e) => setEditedOrderStatus(e.target.value)}
                            className="px-2 py-1 border border-gray-300 rounded-md mr-2"
                          >
                            <option value="" disabled selected>Select Status</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Fulfilled">Fulfilled</option>
                            <option value="Not Delivered">Not Delivered</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Completed">Completed</option>
                          </select>
                          <button
                            onClick={() => handleStatusChange(order, editedOrderStatus)}
                            className="px-2 py-1 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2"
                          >
                            Save
                          </button>   
                        </div>
                      )}
                      <button
                            onClick={() => handleDeleteOrder(order.id)}
                            className="px-2 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                          >
                            Delete
                          </button>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
