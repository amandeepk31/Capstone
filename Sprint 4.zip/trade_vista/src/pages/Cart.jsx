import React, {useState, useEffect} from 'react'
import { CartItemsList, CartTotals, SectionTitle, StripeCheckoutButton } from '../components'
import { Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const Cart = () => {
  
  const navigate = useNavigate();
  const loginState = useSelector((state) => state.auth.isLoggedIn);
  const { cartItems } = useSelector((state) => state.cart);
  console.log('CT ', cartItems);
  const [isOpen, setIsOpen] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const handlePrint = () => {
    setIsPrinting(true);
    window.print();
    setIsPrinting(false);
  };
  const invoice = (
    <>
      <table className="min-w-full divide-y divide-gray-200">
      <tbody className="bg-white divide-y divide-gray-200">
        {cartItems.map((item) => (
          <>
          <tr>
            {/* Product */}
            <td className="px-6 py-4 whitespace-nowrap">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10">
                  <img
                    className="h-10 w-10 rounded-lg object-cover"
                    src={`https://${item.image}`}
                    alt={item.title}
                  />
                </div>
                <div className="ml-4">
                  <div className="text-sm font-medium text-gray-900">{item.title}</div>
                </div>
              </div>
            </td>
            {/* Brand */}
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.brandName}</td>
            </tr>
            <tr>
            {/* Size */}
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.selectedSize}</td>
            {/* Price */}
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${(item.price).toFixed(2)}</td>
          </tr>
          </>
        ))}
      </tbody>
    </table>

    </>
                  ) ;
  const openModal = () => {
    setIsOpen(true);
  };

  const closeModal = () => {
    setIsOpen(false);
  };

  const isCartEmpty = () => {
    if(cartItems.length === 0){
      toast.error("Your cart is empty");
    }else{
      navigate("/thank-you");
    }
  }

  return (
    <>
    <SectionTitle title="Cart" path="Home | Cart" />
    <div className='mt-8 grid gap-8 lg:grid-cols-12 max-w-7xl mx-auto px-10'>
        <div className='lg:col-span-8'>
          <CartItemsList />
        </div>
        <div className='lg:col-span-4 lg:pl-4'>
          <CartTotals />
          {loginState ? (
            // <button onClick={isCartEmpty} className='btn bg-blue-600 hover:bg-blue-500 text-white btn-block mt-8'>
            //   order now
            // </button>
            <>
              <button onClick={openModal} className='btn bg-blue-600 hover:bg-blue-500 text-white btn-block mt-8'>
               Invoice
              </button>
              <div className="card">
                <div className='card-body'>
                  <p className="flex justify-between text-sm  text-accent-content">
                    *Please use the following test credit card for payments*
                  </p>
                  <p className="flex justify-between text-sm pb-2 text-accent-content">
                    4242 4242 4242 4242 - Exp: 01/25 - CVV: 123
                  </p>
                  <StripeCheckoutButton />
                </div>
              </div>
              
            </>
          ) : (
            <Link to='/login' className='btn bg-blue-600 hover:bg-blue-500 btn-block text-white mt-8'>
              please login
            </Link>
          )}
        </div>
      </div>
            {isOpen && (
  <div className="fixed z-10 inset-0 overflow-y-auto">
    <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <div className="fixed inset-0 transition-opacity" aria-hidden="true">
        {/* Background overlay */}
        <div className={`absolute inset-0 bg-gray-900 opacity-100`}></div>
      </div>
      <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
      <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all  sm:my-8 sm:align-middle sm:w-full">
        <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
          <h3 className="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Invoice</h3>
          <div className="mt-5">
            {invoice}
          </div>
        </div>
        <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
          {!isPrinting && (
            <>
              <button type="button" onClick={handlePrint} className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-500 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                Print
              </button>
            </>              
          )}
          <button onClick={closeModal} type="button" className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-500 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
)}

    </>
  )
}

export default Cart