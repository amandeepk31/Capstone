import React, {useState,useEffect} from 'react'
import { Outlet } from 'react-router-dom'
import { Footer, AdminHeader, Sidebar } from '../components'
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const AdminLayout = () => {
    const navigate = useNavigate();
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const loginState = useSelector((state) => state.auth.isLoggedIn);
    const role = useSelector((state) => state.auth.role);
    useEffect(() => {
        if(loginState === false && role === 'user')
        {
            toast.error('You\'re not authorized');
            navigate("/");
        }
        if(loginState === true && role === 'user')
        {
            toast.error('You\'re not authorized');
            navigate("/");
        }
    },[loginState,role]);
  return (
    <div className="flex h-screen overflow-hidden">

    <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

        <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
            <AdminHeader sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

            <main>
                <div className="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
                    <Outlet />
                </div>
            </main>

        </div>

        {/* <Outlet /> */}
        
     
    {/* <Outlet /> */}
    {/* <Footer /> */}
    </div>
  )
}

export default AdminLayout