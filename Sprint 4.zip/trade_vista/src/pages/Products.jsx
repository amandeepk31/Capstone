import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [searchText, setSearchText] = useState('');
  const navigate = useNavigate();
  
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = () => {
    axios.get('http://localhost:8080/products')
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        toast.error('Error fetching products: ', error);
      });
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleDeleteProduct = (productId) => {
    axios.delete(`http://localhost:8080/products/${productId}`)
      .then(() => {
        fetchProducts();
        toast.success('Product deleted successfully');
      })
      .catch((error) => {
        console.error('Error deleting product:', error);
        toast.error('Error deleting product: ', error);
      });
  };

  const handleEditProduct = (productId) => {
    navigate('/admin/edit-product/'+productId);
    console.log('PID ', productId);
        toast.success('Product ID: ', productId);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchText.toLowerCase())
  );

  const handleAddProduct = () => {
    navigate('/admin/add-product');
  };

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Products</h2>
        {/* Add Product Button */}
        <button
          onClick={handleAddProduct}
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
        >
          Add Product
        </button>
      </header>
      <div className="p-3">
        {/* Search */}
        <div className="mb-4">
          <input
            type="text"
            value={searchText}
            onChange={handleSearch}
            placeholder="Search by product name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            {/* Table header */}
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Name</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Category</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Brand</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Price</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">In Stock</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Rating</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
              </tr>
            </thead>
            {/* Table body */}
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
              {
                filteredProducts.map((product, index) => (
                <tr key={index}>
                    <td className="p-2 whitespace-nowrap">{product.name}</td>
                    <td className="p-2 whitespace-nowrap">{product.category}</td>
                    <td className="p-2 whitespace-nowrap">{product.brandName}</td>
                    <td className="p-2 whitespace-nowrap text-success">{product.price.current.text}</td>
                    <td className="p-2 whitespace-nowrap">{product.isInStock ? 'Yes' : 'No'}</td>
                    <td className="p-2 whitespace-nowrap">{product.rating}</td>
                    <td className="p-2 whitespace-nowrap">
                    <button
                        onClick={() => handleEditProduct(product.id)}
                        className="px-2 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 mr-2"
                    >
                        Edit
                    </button>    
                    <button
                        onClick={() => handleDeleteProduct(product.id)}
                        className="px-2 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                    >
                        Delete
                    </button>
                    </td>
                </tr>
                ))
              }
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
