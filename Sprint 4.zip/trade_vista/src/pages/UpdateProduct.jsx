import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate,useParams } from 'react-router-dom';

const UpdateProduct = () => {
  const navigate = useNavigate();
  const { productId } = useParams();
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [product, setProduct] = useState({
    id: productId, 
    name: '',
    description: '',
    isInStock: true,
    gender: '',
    category: '',
    availableSizes: [],
    rating: 0,
    reviews: [],
    totalReviewCount: 0,
    productionDate: new Date().toISOString(),
    price: {
      current: {
        value: 0,
        text: '',
      },
    },
    brandName: '',
    productCode: 0,
    imageUrl: '',
    additionalImageUrls: [],
  });

  useEffect(() => {
    fetchCategories();
    fetchBrands();
    fetchProduct();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:8080/categories');
      setCategories(response.data);
    } catch (error) {
      console.error('Failed to fetch categories:', error.message);
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await axios.get('http://localhost:8080/brands');
      setBrands(response.data);
    } catch (error) {
      console.error('Failed to fetch brands:', error.message);
    }
  };

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/products/${productId}`);
      setProduct(response.data);
    } catch (error) {
      console.error('Failed to fetch product:', error.message);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'availableSizes' || name === 'additionalImageUrls') {
      const valuesArray = value.split(',').map((item) => item.trim());
      setProduct((prevProduct) => ({
        ...prevProduct,
        [name]: valuesArray,
      }));
    } else if (name === 'price_value') {
      setProduct((prevProduct) => ({
        ...prevProduct,
        price: {
          ...prevProduct.price,
          current: {
            ...prevProduct.price.current,
            value: value,
          },
        },
      }));
    } else if (name === 'price_text') {
      setProduct((prevProduct) => ({
        ...prevProduct,
        price: {
          ...prevProduct.price,
          current: {
            ...prevProduct.price.current,
            text: value,
          },
        },
      }));
    } else {
      setProduct((prevProduct) => ({
        ...prevProduct,
        [name]: value,
      }));
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    try {
      await axios.put(`http://localhost:8080/products/${productId}`, product);
      console.log('Product updated successfully:', product);
      toast.success('Product updated successfully');
      navigate('/admin/products');
    } catch (error) {
      console.error('Failed to update product:', error.message);
      toast.error('Failed to update product');
    }
  };

  return (
    <div className="container mx-auto">
      <h1 className="text-2xl font-bold my-4">Update Product</h1>
      <form onSubmit={handleUpdate}>
        <div className="mb-4">
          <label htmlFor="name" className="block text-sm font-medium">
            Name
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={product.name}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="description" className="block text-sm font-medium">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={product.description}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          ></textarea>
        </div>
        <div className="mb-4">
          <label htmlFor="isInStock" className="block text-sm font-medium">
            Is In Stock
          </label>
          <input
            type="checkbox"
            id="isInStock"
            name="isInStock"
            checked={product.isInStock}
            onChange={(e) => setProduct((prevProduct) => ({ ...prevProduct, isInStock: e.target.checked }))}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="gender" className="block text-sm font-medium">
            Gender
          </label>
          <input
            type="text"
            id="gender"
            name="gender"
            value={product.gender}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="category" className="block text-sm font-medium">
            Category
          </label>
          <select
            id="category"
            name="category"
            value={product.category}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          >
            <option value="">Select Category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
        <div className="mb-4">
          <label htmlFor="availableSizes" className="block text-sm font-medium">
            Available Sizes (comma-separated)
          </label>
          <input
            type="text"
            id="availableSizes"
            name="availableSizes"
            value={product.availableSizes.join(', ')}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="rating" className="block text-sm font-medium">
            Rating
          </label>
          <input
            type="number"
            id="rating"
            name="rating"
            value={product.rating}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="totalReviewCount" className="block text-sm font-medium">
            Total Review Count
          </label>
          <input
            type="number"
            id="totalReviewCount"
            name="totalReviewCount"
            value={product.totalReviewCount}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="productionDate" className="block text-sm font-medium">
            Production Date
          </label>
          <input
            type="datetime-local"
            id="productionDate"
            name="productionDate"
            value={product.productionDate}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="price_value" className="block text-sm font-medium">
            Price Value
          </label>
          <input
            type="number"
            id="price_value"
            name="price_value"
            value={product.price.current.value}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="price_text" className="block text-sm font-medium">
            Price Text
          </label>
          <input
            type="text"
            id="price_text"
            name="price_text"
            value={product.price.current.text}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="brandName" className="block text-sm font-medium">
            Brand Name
          </label>
          <select
            id="brandName"
            name="brandName"
            value={product.brandName}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          >
            <option value="">Select Brand</option>
            {brands.map((brand) => (
              <option key={brand.id} value={brand.name}>
                {brand.name}
              </option>
            ))}
          </select>
        </div>
        <div className="mb-4">
          <label htmlFor="productCode" className="block text-sm font-medium">
            Product Code
          </label>
          <input
            type="number"
            id="productCode"
            name="productCode"
            value={product.productCode}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="imageUrl" className="block text-sm font-medium">
            Image URL
          </label>
          <input
            type="text"
            id="imageUrl"
            name="imageUrl"
            value={product.imageUrl}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="additionalImageUrls" className="block text-sm font-medium">
            Additional Image URLs (comma-separated)
          </label>
          <input
            type="text"
            id="additionalImageUrls"
            name="additionalImageUrls"
            value={product.additionalImageUrls.join(', ')}
            onChange={handleInputChange}
            className="mt-1 p-2 border border-gray-300 rounded-md w-full"
          />
        </div>
        <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Update Product
        </button>
      </form>
    </div>
  );
};

export default UpdateProduct;
