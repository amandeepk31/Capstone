import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function Brands() {
  const [brands, setBrands] = useState([]);
  const [newBrandName, setNewBrandName] = useState('');
  const [editBrandName, setEditBrandName] = useState('');
  const [editBrandId, setEditBrandId] = useState('');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    fetchBrands();
  }, []);

  const fetchBrands = () => {
    axios.get('http://localhost:8080/brands')
      .then((response) => {
        setBrands(response.data);
      })
      .catch((error) => {
        console.error('Error fetching brands:', error);
        toast.error('Error fetching brands: ', error);
      });
  };

  const addBrand = () => {
    if (newBrandName.trim() !== '') {
      axios.post('http://localhost:8080/brands', { name: newBrandName })
        .then(() => {
          fetchBrands();
          setNewBrandName('');
          toast.success('Brand added successfully');
        })
        .catch((error) => {
          console.error('Error adding brand:', error);
          toast.error('Error adding brand: ', error);
        });
    }
  };

  const editBrand = () => {
    if (editBrandName.trim() !== '') {
      axios.put(`http://localhost:8080/brands/${editBrandId}`, { name: editBrandName })
        .then(() => {
          fetchBrands();
          setEditBrandName('');
          setEditBrandId('');
          toast.success('Brand updated successfully');
        })
        .catch((error) => {
          console.error('Error updating brand:', error);
          toast.error('Error updating brand: ', error);
        });
    }
  };

  const deleteBrand = (id) => {
    axios.delete(`http://localhost:8080/brands/${id}`)
      .then(() => {
        fetchBrands();
        toast.success('Brand deleted');
      })
      .catch((error) => {
        console.error('Error deleting brand:', error);
        toast.error('Error deleting brand: ', error);
      });
  };

  const handleEdit = (id, name) => {
    setEditBrandName(name);
    setEditBrandId(id);
  };

  const filteredBrands = brands.filter(brand =>
    brand.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Brands</h2>
      </header>
      <div className="p-3">

        {/* Add Brand */}
        <div className="mb-4">
          <input
            type="text"
            value={newBrandName}
            onChange={(e) => setNewBrandName(e.target.value)}
            placeholder="Enter new brand name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
          <button
            onClick={addBrand}
            className="mt-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            Add Brand
          </button>
        </div>

        {/* Search */}
        <div className="mb-4">
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search by brand name"
            className="px-3 py-2 border border-gray-300 rounded-md w-full"
          />
        </div>

        {/* Edit Brand */}
        {editBrandId && (
          <div className="mb-4">
            <input
              type="text"
              value={editBrandName}
              onChange={(e) => setEditBrandName(e.target.value)}
              placeholder="Enter edited brand name"
              className="px-3 py-2 border border-gray-300 rounded-md w-full"
            />
            <button
              onClick={editBrand}
              className="mt-2 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
            >
              Update Brand
            </button>
          </div>
        )}

        {/* Brands Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">ID</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Name</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
              </tr>
            </thead>
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
              {
                filteredBrands.map((brand, index) => (
                  <tr key={index}>
                    <td className="p-2 whitespace-nowrap">{index+1}</td>
                    <td className="p-2 whitespace-nowrap">{brand.name}</td>
                    <td className="p-2 whitespace-nowrap">
                      <button
                        onClick={() => handleEdit(brand.id, brand.name)}
                        className="px-2 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 mr-2"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteBrand(brand.id)}
                        className="px-2 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
