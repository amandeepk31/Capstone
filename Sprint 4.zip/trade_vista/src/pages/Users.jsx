import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({
    id: '',
    name: '',
    lastname: '',
    email: '',
    phone: '',
    adress: '',
    password: '',
    role: 'user',
    userWishlist: [],
  });
  const [isEditUser, setIsEditUser] = useState(false);

  const fetchUsers = () => {
    axios.get('http://localhost:8080/user')
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error('Error fetching users:', error);
        toast.error('Error fetching users: ', error);
      });
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewUser((prevUser) => ({
        ...prevUser,
        [name]: value,
    }));
  };

  const handleAddUser = () => {
    setShowAddUser(true);
    setIsEditUser(false);
    setNewUser({
            id: '',
            name: '',
            lastname: '',
            email: '',
            phone: '',
            adress: '',
            password: '',
            role: 'user',
            userWishlist: [],
          });
  };

  const generateRandomId = () => {
    const min = 10000;
    const max = 99999;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEditUser) {
      axios.put(`http://localhost:8080/user/${newUser.id}`, newUser)
        .then((response) => {
          setNewUser({
            id: '',
            name: '',
            lastname: '',
            email: '',
            phone: '',
            adress: '',
            password: '',
            role: 'user',
            userWishlist: [],
          });
          setShowAddUser(false);
          toast.success('User updated successfully');
          fetchUsers();
        })
        .catch((error) => {
          console.error('Error updating user: ', error);
          toast.error('Error updating user: ', error);
        });
    } else {
        newUser.id = '' + generateRandomId();
      axios.post('http://localhost:8080/user', newUser)
        .then((response) => {
          setShowAddUser(false);
          setNewUser({
            id: '',
            name: '',
            lastname: '',
            email: '',
            phone: '',
            adress: '',
            password: '',
            role: 'user',
            userWishlist: [],
          });
          toast.success('User added successfully');
          fetchUsers();
        })
        .catch((error) => {
          console.error('Error adding user: ', error);
          toast.error('Error adding user: ', error);
        });
    }
  };

  const handleEditUser = (user) => {
    console.log('user ', user);
    setNewUser(user);
    setShowAddUser(true);
    setIsEditUser(true);
  };

  const handleDeleteUser = (id) => {
    axios.delete(`http://localhost:8080/user/${id}`)
      .then(() => {
        fetchUsers();
        toast.success('User deleted successfully');
      })
      .catch((error) => {
        console.error('Error deleting user: ', error);
        toast.error('Error deleting user: ', error);
      });
  };

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Users</h2>
        <button onClick={handleAddUser} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Add User
        </button>
      </header>
      {showAddUser && (
        <form onSubmit={handleSubmit} className="p-5 border-t border-slate-100 dark:border-slate-700">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium">First Name</label>
              <input type="text" id="name" name="name" value={newUser.name} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
            <div>
              <label htmlFor="lastname" className="block text-sm font-medium">Last Name</label>
              <input type="text" id="lastname" name="lastname" value={newUser.lastname} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium">Email</label>
              <input type="email" id="email" name="email" value={newUser.email} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium">Phone</label>
              <input type="tel" id="phone" name="phone" value={newUser.phone} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
            <div>
              <label htmlFor="adress" className="block text-sm font-medium">Address</label>
              <input type="text" id="adress" name="adress" value={newUser.adress} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium">Password</label>
              <input type="password" id="password" name="password" value={newUser.password} onChange={handleInputChange} className="mt-1 p-2 border border-gray-300 rounded-md w-full" />
            </div>
          </div>
          <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 mt-4 rounded">{isEditUser ? 'Update User' : 'Create User'}</button>
        </form>
      )}
      <div className="p-3">
        {/* Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            {/* Table header */}
            <thead className="text-xs font-semibold uppercase text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">First Name</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Last Name</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Email</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Phone</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Address</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">Actions</div>
                </th>
              </tr>
            </thead>
            {/* Table body */}
            <tbody className="text-sm divide-y divide-slate-100 dark:divide-slate-700">
              {users.map((user) => (
                <tr key={user.id}>
                  <td className="p-2 whitespace-nowrap">
                    <div className="text-left">{user.name}</div>
                  </td>
                  <td className="p-2 whitespace-nowrap">
                    <div className="text-left">{user.lastname}</div>
                  </td>
                  <td className="p-2 whitespace-nowrap">
                    <div className="text-left">{user.email}</div>
                  </td>
                  <td className="p-2 whitespace-nowrap">
                    <div className="text-left">{user.phone}</div>
                  </td>
                  <td className="p-2 whitespace-nowrap">
                    <div className="text-left">{user.adress}</div>
                  </td>
                  <td className="p-2 whitespace-nowrap">
                    <button onClick={() => handleEditUser(user)} className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded mr-2">Edit</button>
                    <button onClick={() => handleDeleteUser(user.id)} className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Users;
