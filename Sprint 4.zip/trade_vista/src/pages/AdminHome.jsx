import React, {useState,useEffect, useRef} from 'react'
import axios from 'axios';
import Chart from 'chart.js/auto';
import 'chartjs-adapter-moment/dist/chartjs-adapter-moment';
import { toast } from "react-toastify";

export default function AdminHome() {

    const [orderGraphData, setOrderGraphData] = useState([]);
  const [orderGraphDataMonth, setOrderGraphDataMonth] = useState([]);
  const [totalPriceSum, setTotalPriceSum] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);

  

    useEffect(() => {
    axios.get('http://localhost:8080/orders')
        .then((response) => {
          setTotalOrders(response.data.length);
          setTotalPriceSum(response.data.reduce((total, order) => total + order.subtotal, 0))
        })
        .catch((error) => {
          console.error('Error fetching graph data: ', error);
          toast.error('Error fetching graph data: ', error);
        });
    axios.get('http://localhost:8080/user')
        .then((response) => {
          setTotalUsers(response.data.length);
        })
        .catch((error) => {
          console.error('Error fetching graph data: ', error);
          toast.error('Error fetching graph data: ', error);
        });     
  }, []);


  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['October','November','December','January', 'February', 'March'],
        datasets: [{
          label: 'Sales',
          data: [313, 217, 398, 548, 476, 703],
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
        }],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }, [chartRef]);

  return (
    <>
    <div className="relative bg-indigo-200 dark:bg-indigo-500 p-4 sm:p-6 rounded-sm overflow-hidden mb-8">
      {/* Background illustration */}
      <div className="absolute right-0 top-0 -mt-4 mr-16 pointer-events-none hidden xl:block" aria-hidden="true">
        <svg width="319" height="198" xmlnsXlink="http://www.w3.org/1999/xlink">
          <defs>
            <path id="welcome-a" d="M64 0l64 128-64-20-64 20z" />
            <path id="welcome-e" d="M40 0l40 80-40-12.5L0 80z" />
            <path id="welcome-g" d="M40 0l40 80-40-12.5L0 80z" />
            <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="welcome-b">
              <stop stopColor="#A5B4FC" offset="0%" />
              <stop stopColor="#818CF8" offset="100%" />
            </linearGradient>
            <linearGradient x1="50%" y1="24.537%" x2="50%" y2="100%" id="welcome-c">
              <stop stopColor="#4338CA" offset="0%" />
              <stop stopColor="#6366F1" stopOpacity="0" offset="100%" />
            </linearGradient>
          </defs>
          <g fill="none" fillRule="evenodd">
            <g transform="rotate(64 36.592 105.604)">
              <mask id="welcome-d" fill="#fff">
                <use xlinkHref="#welcome-a" />
              </mask>
              <use fill="url(#welcome-b)" xlinkHref="#welcome-a" />
              <path fill="url(#welcome-c)" mask="url(#welcome-d)" d="M64-24h80v152H64z" />
            </g>
            <g transform="rotate(-51 91.324 -105.372)">
              <mask id="welcome-f" fill="#fff">
                <use xlinkHref="#welcome-e" />
              </mask>
              <use fill="url(#welcome-b)" xlinkHref="#welcome-e" />
              <path fill="url(#welcome-c)" mask="url(#welcome-f)" d="M40.333-15.147h50v95h-50z" />
            </g>
            <g transform="rotate(44 61.546 392.623)">
              <mask id="welcome-h" fill="#fff">
                <use xlinkHref="#welcome-g" />
              </mask>
              <use fill="url(#welcome-b)" xlinkHref="#welcome-g" />
              <path fill="url(#welcome-c)" mask="url(#welcome-h)" d="M40.333-15.147h50v95h-50z" />
            </g>
          </g>
        </svg>
      </div>

      {/* Content */}
      <div className="relative">
        <h1 className="text-2xl md:text-3xl text-slate-800 dark:text-slate-100 font-bold mb-1">Good afternoon, Trade Vista. 👋</h1>
        <p className="dark:text-indigo-200">Here is what’s happening with your projects today:</p>
      </div>
    </div>

    <div className="grid grid-cols-12 gap-6">
        {/* Card 1 */}
        <div className="flex flex-col col-span-full sm:col-span-6 xl:col-span-4 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
            <div className="px-5 pt-5 pb-5">
                <header className="flex justify-between items-start mb-2">
                
                </header>
                <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">Number of Orders</h2>
                {/* <div className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mb-1">Sales</div> */}
                <div className="flex items-start">
                <div className="text-3xl font-bold text-slate-800 dark:text-slate-100 mr-2">{totalOrders}</div>
                {/* <div className="text-sm font-semibold text-white px-1.5 bg-emerald-500 rounded-full">+49%</div> */}
                </div>
            </div>
        </div>

        {/* Card 2 */}
        <div className="flex flex-col col-span-full sm:col-span-6 xl:col-span-4 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
            <div className="px-5 pt-5 pb-5">
                <header className="flex justify-between items-start mb-2">
                
                </header>
                <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">Sales</h2>
                {/* <div className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mb-1">Sales</div> */}
                <div className="flex items-start">
                <div className="text-3xl font-bold text-slate-800 dark:text-slate-100 mr-2">${totalPriceSum}</div>
                {/* <div className="text-sm font-semibold text-white px-1.5 bg-emerald-500 rounded-full">+49%</div> */}
                </div>
            </div>
        </div>

        {/* Card 3 */}
        <div className="flex flex-col col-span-full sm:col-span-6 xl:col-span-4 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
            <div className="px-5 pt-5 pb-5">
                <header className="flex justify-between items-start mb-2">
                
                </header>
                <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">Users</h2>
                {/* <div className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mb-1">Sales</div> */}
                <div className="flex items-start">
                <div className="text-3xl font-bold text-slate-800 dark:text-slate-100 mr-2">{totalUsers}</div>
                {/* <div className="text-sm font-semibold text-white px-1.5 bg-emerald-500 rounded-full">+49%</div> */}
                </div>
            </div>
        </div>

        <div className="flex flex-col col-span-full sm:col-span-5 bg-white light:bg-slate-800 shadow-lg rounded-sm border border-slate-200 light:border-slate-700">
        <header className="px-5 py-4 border-b border-slate-100 light:border-slate-700 flex items-center">
            <h2 className="font-semibold text-slate-800 light:text-slate-100">Sales</h2>
        </header>
            <div className="w-full h-64 bg-white shadow-md rounded-lg overflow-hidden">
                <canvas ref={chartRef} className="w-full h-full" style={{ width: '100%' }} />
            </div>
        </div> 

    </div>
</>
  )
}
