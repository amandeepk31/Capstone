-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 29, 2024 at 11:12 PM
-- Server version: 5.7.38
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trade_vista`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOrders` ()   BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE j INT DEFAULT 1;
    DECLARE month VARCHAR(255);
    DECLARE order_date DATE;
    DECLARE price DECIMAL(10, 0);

    WHILE i <= 6 DO
        SET month = CASE i
            WHEN 1 THEN 'January'
            WHEN 2 THEN 'February'
            WHEN 3 THEN 'March'
            WHEN 4 THEN 'December' -- Last year's months
            WHEN 5 THEN 'November'
            WHEN 6 THEN 'October'
        END;

        SET order_date = CASE i
            WHEN 1 THEN '2024-01-01' -- This year's months
            WHEN 2 THEN '2024-02-01'
            WHEN 3 THEN '2024-03-01'
            WHEN 4 THEN '2023-12-01' -- Last year's months
            WHEN 5 THEN '2023-11-01'
            WHEN 6 THEN '2023-10-01'
        END;

        WHILE j <= 10 DO
            SET price = FLOOR(RAND() * (1500 - 500 + 1) + 500); -- Generate random price between 5000 and 15000

            INSERT INTO `Order` (`UserID`, `Status`, `price`, `Date`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`)
            VALUES
                (1, 'Completed', price, order_date, NOW(), 1, NOW(), 1);

            SET j = j + 1;
        END WHILE;

        SET i = i + 1;
        SET j = 1;
    END WHILE;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Address`
--

CREATE TABLE `Address` (
  `AddressID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Street` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `ZipCode` varchar(10) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Address`
--

INSERT INTO `Address` (`AddressID`, `UserID`, `Street`, `City`, `State`, `ZipCode`, `Country`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 'Street1', 'City1', 'State1', '12345', 'Country1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 'Street2', 'City2', 'State2', '23456', 'Country2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Category`
--

CREATE TABLE `Category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Category`
--

INSERT INTO `Category` (`CategoryID`, `CategoryName`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'Hats', '2024-03-01 20:54:42', 1, '2024-03-19 19:24:44', 1),
(2, 'Jackets', '2024-03-01 20:54:42', 2, '2024-03-19 19:24:49', 2),
(3, 'Sneakers', '2024-03-01 20:54:42', 3, '2024-03-19 19:24:53', 3),
(4, 'Women', '2024-03-01 20:54:42', 4, '2024-03-19 19:24:56', 4),
(5, 'Mens', '2024-03-01 20:54:42', 5, '2024-03-19 19:24:59', 5),
(6, 'Shoes', '2024-03-22 18:49:35', NULL, '2024-03-22 18:49:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Order`
--

CREATE TABLE `Order` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Status` varchar(50) NOT NULL,
  `price` decimal(10,0) NOT NULL DEFAULT '0',
  `Date` date NOT NULL,
  `CreatedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Order`
--

INSERT INTO `Order` (`OrderID`, `UserID`, `Status`, `price`, `Date`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(25, 1, 'Completed', '897', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(26, 1, 'Completed', '987', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(27, 1, 'Completed', '742', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(28, 1, 'Completed', '1253', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(29, 1, 'Completed', '535', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(30, 1, 'Completed', '1419', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(31, 1, 'Completed', '986', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(32, 1, 'Completed', '1175', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(33, 1, 'Completed', '1415', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(34, 1, 'Completed', '1048', '2024-01-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(35, 1, 'Completed', '1498', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(36, 1, 'Completed', '845', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(37, 1, 'Completed', '1232', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(38, 1, 'Completed', '1122', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(39, 1, 'Completed', '1417', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(40, 1, 'Completed', '1216', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(41, 1, 'Completed', '1330', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(42, 1, 'Completed', '502', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(43, 1, 'Completed', '1023', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(44, 1, 'Completed', '1106', '2024-02-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(45, 1, 'Completed', '960', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(46, 1, 'Completed', '985', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(47, 1, 'Completed', '544', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(48, 1, 'Completed', '1267', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(49, 1, 'Completed', '1200', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(50, 1, 'Completed', '698', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(51, 1, 'Completed', '1393', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(52, 1, 'Completed', '1368', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(53, 1, 'Completed', '1160', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(54, 1, 'Completed', '1199', '2024-03-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(55, 1, 'Completed', '1012', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(56, 1, 'Completed', '966', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(57, 1, 'Completed', '1293', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(58, 1, 'Completed', '1067', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(59, 1, 'Completed', '956', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(60, 1, 'Completed', '1078', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(61, 1, 'Completed', '1022', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(62, 1, 'Completed', '1378', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(63, 1, 'Completed', '1320', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(64, 1, 'Completed', '966', '2023-12-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(65, 1, 'Completed', '1371', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(66, 1, 'Completed', '1454', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(67, 1, 'Completed', '659', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(68, 1, 'Completed', '1435', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(69, 1, 'Completed', '696', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(70, 1, 'Completed', '676', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(71, 1, 'Completed', '793', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(72, 1, 'Completed', '1439', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(73, 1, 'Completed', '1310', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(74, 1, 'Completed', '735', '2023-11-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(75, 1, 'Completed', '1248', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(76, 1, 'Completed', '533', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(77, 1, 'Completed', '1425', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(78, 1, 'Completed', '1024', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(79, 1, 'Completed', '1343', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(80, 1, 'Completed', '1144', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(81, 1, 'Completed', '1190', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(82, 1, 'Completed', '1018', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(83, 1, 'Completed', '1018', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1),
(84, 1, 'Completed', '539', '2023-10-01', '2024-03-29 20:43:19', 1, '2024-03-29 20:43:19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `OrderDetail`
--

CREATE TABLE `OrderDetail` (
  `OrderDetailID` int(11) NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `CreatedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderDetail`
--

INSERT INTO `OrderDetail` (`OrderDetailID`, `OrderID`, `ProductID`, `Quantity`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 11, 25, 1, '2024-03-19 20:42:29', NULL, '2024-03-19 20:42:29', NULL),
(2, 14, 25, 1, '2024-03-19 20:44:55', NULL, '2024-03-19 20:44:55', NULL),
(3, 15, 25, 1, '2024-03-19 20:45:28', NULL, '2024-03-19 20:45:28', NULL),
(4, 16, 25, 1, '2024-03-19 20:47:14', NULL, '2024-03-19 20:47:14', NULL),
(5, 17, 25, 1, '2024-03-22 18:58:07', NULL, '2024-03-22 18:58:07', NULL),
(6, 18, 25, 1, '2024-03-22 18:59:33', NULL, '2024-03-22 18:59:33', NULL),
(7, 19, 25, 1, '2024-03-22 19:00:51', NULL, '2024-03-22 19:00:51', NULL),
(8, 20, 25, 1, '2024-03-22 19:01:37', NULL, '2024-03-22 19:01:37', NULL),
(9, 21, 25, 1, '2024-03-22 19:04:46', NULL, '2024-03-22 19:04:46', NULL),
(10, 22, 2, 1, '2024-03-22 19:54:40', NULL, '2024-03-22 19:54:40', NULL),
(11, 23, 2, 1, '2024-03-22 19:56:04', NULL, '2024-03-22 19:56:04', NULL),
(12, 24, 2, 1, '2024-03-22 20:10:58', NULL, '2024-03-22 20:10:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `ProductID` int(11) NOT NULL,
  `SellerID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Description` text,
  `Price` decimal(10,2) NOT NULL,
  `Stock` int(11) NOT NULL,
  `imageUrl` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`ProductID`, `SellerID`, `CategoryID`, `ProductName`, `Description`, `Price`, `Stock`, `imageUrl`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, NULL, 1, 'Brown Brim', 'Classic brown brim hat for everyday wear.', '25.00', 100, 'https://i.ibb.co/ZYW3VTp/brown-brim.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(2, NULL, 1, 'Blue Beanie', 'Stay warm with this stylish blue beanie.', '18.00', 100, 'https://i.ibb.co/ypkgK0X/blue-beanie.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(3, NULL, 1, 'Brown Cowboy', 'Channel your inner cowboy with this brown hat.', '35.00', 100, 'https://i.ibb.co/QdJwgmp/brown-cowboy.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(4, NULL, 1, 'Grey Brim', 'Versatile grey brim hat for any occasion.', '25.00', 100, 'https://i.ibb.co/RjBLWxB/grey-brim.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(5, NULL, 1, 'Green Beanie', 'Add a pop of color with this green beanie.', '18.00', 100, 'https://i.ibb.co/YTjW3vF/green-beanie.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(6, NULL, 1, 'Palm Tree Cap', 'Stay cool and stylish with this palm tree cap.', '14.00', 100, 'https://i.ibb.co/rKBDvJX/palm-tree-cap.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(7, NULL, 1, 'Red Beanie', 'Make a statement with this bold red beanie.', '18.00', 100, 'https://i.ibb.co/bLB646Z/red-beanie.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(8, NULL, 1, 'Wolf Cap', 'Embrace your wild side with this wolf cap.', '14.00', 100, 'https://i.ibb.co/1f2nWMM/wolf-cap.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(9, NULL, 1, 'Blue Snapback', 'Classic blue snapback cap for a sporty look.', '16.00', 100, 'https://i.ibb.co/X2VJP2W/blue-snapback.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(10, NULL, 2, 'Adidas NMD', 'Get ready to hit the streets with these Adidas NMD sneakers.', '220.00', 100, 'https://i.ibb.co/0s3pdnc/adidas-nmd.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(11, NULL, 2, 'Adidas Yeezy', 'Upgrade your sneaker game with Adidas Yeezy.', '280.00', 100, 'https://i.ibb.co/dJbG1cT/yeezy.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(12, NULL, 2, 'Black Converse', 'Classic black Converse sneakers for everyday wear.', '110.00', 100, 'https://i.ibb.co/bPmVXyP/black-converse.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(13, NULL, 2, 'Nike White AirForce', 'Step out in style with Nike White AirForce sneakers.', '160.00', 100, 'https://i.ibb.co/1RcFPk0/white-nike-high-tops.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(14, NULL, 2, 'Nike Red High Tops', 'Make a statement with these bold red high-top sneakers.', '160.00', 100, 'https://i.ibb.co/QcvzydB/nikes-red.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(15, NULL, 2, 'Nike Brown High Tops', 'Add a touch of sophistication with Nike Brown High Tops.', '160.00', 100, 'https://i.ibb.co/fMTV342/nike-brown.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(16, NULL, 2, 'Air Jordan Limited', 'Score style points with Air Jordan Limited edition sneakers.', '190.00', 100, 'https://i.ibb.co/w4k6Ws9/nike-funky.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(17, NULL, 2, 'Timberlands', 'Stay rugged and trendy with Timberlands.', '200.00', 100, 'https://i.ibb.co/Mhh6wBg/timberlands.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(18, NULL, 3, 'Black Jean Shearling', 'Stay warm and stylish with this black jean shearling jacket.', '125.00', 100, 'https://i.ibb.co/XzcwL5s/black-shearling.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(19, NULL, 3, 'Blue Jean Jacket', 'Classic blue jean jacket for a casual look.', '90.00', 100, 'https://i.ibb.co/mJS6vz0/blue-jean-jacket.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(20, NULL, 3, 'Grey Jean Jacket', 'Versatile grey jean jacket for any occasion.', '90.00', 100, 'https://i.ibb.co/N71k1ML/grey-jean-jacket.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(21, NULL, 3, 'Brown Shearling', 'Add a touch of luxury with this brown shearling jacket.', '165.00', 100, 'https://i.ibb.co/s96FpdP/brown-shearling.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(22, NULL, 3, 'Tan Trench', 'Stay stylish in any weather with this tan trench coat.', '185.00', 100, 'https://i.ibb.co/M6hHc3F/brown-trench.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(23, NULL, 4, 'Blue Tanktop', 'Cool and comfortable blue tank top for women.', '25.00', 100, 'https://i.ibb.co/7CQVJNm/blue-tank.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(24, NULL, 4, 'Floral Blouse', 'Floral pattern blouse for a touch of elegance.', '20.00', 100, 'https://i.ibb.co/4W2DGKm/floral-blouse.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(25, NULL, 4, 'Floral Dress', 'Dress up in style with this floral pattern dress.', '80.00', 100, 'https://i.ibb.co/KV18Ysr/floral-skirt.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(26, NULL, 4, 'Red Dots Dress', 'Make a statement with this red dots dress.', '80.00', 100, 'https://i.ibb.co/N3BN1bh/red-polka-dot-dress.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(27, NULL, 4, 'Striped Sweater', 'Stay cozy and fashionable with this striped sweater.', '45.00', 100, 'https://i.ibb.co/KmSkMbH/striped-sweater.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(28, NULL, 4, 'Yellow Track Suit', 'Stand out in the crowd with this yellow track suit.', '135.00', 100, 'https://i.ibb.co/v1cvwNf/yellow-track-suit.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(29, NULL, 4, 'White Blouse', 'Classic white blouse for a timeless look.', '20.00', 100, 'https://i.ibb.co/qBcrsJg/white-vest.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(30, NULL, 5, 'Camo Down Vest', 'Stay warm and stylish with this camo down vest.', '325.00', 100, 'https://i.ibb.co/xJS0T3Y/camo-vest.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(31, NULL, 5, 'Floral T-shirt', 'Add a touch of nature with this floral t-shirt.', '20.00', 100, 'https://i.ibb.co/qMQ75QZ/floral-shirt.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(32, NULL, 5, 'Black & White Longsleeve', 'Classic black and white long sleeve shirt for everyday wear.', '25.00', 100, 'https://i.ibb.co/55z32tw/long-sleeve.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(33, NULL, 5, 'Pink T-shirt', 'Add a pop of color with this pink t-shirt.', '25.00', 100, 'https://i.ibb.co/RvwnBL8/pink-shirt.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(34, NULL, 5, 'Jean Long Sleeve', 'Casual and comfortable jean long sleeve shirt.', '40.00', 100, 'https://i.ibb.co/VpW4x5t/roll-up-jean-shirt.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL),
(35, NULL, 5, 'Burgundy T-shirt', 'Add a touch of sophistication with this burgundy t-shirt.', '25.00', 100, 'https://i.ibb.co/mh3VM1f/polka-dot-shirt.png', '2024-03-19 18:28:20', NULL, '2024-03-19 18:28:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ProductImage`
--

CREATE TABLE `ProductImage` (
  `ImageID` int(11) NOT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `ImageURL` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductImage`
--

INSERT INTO `ProductImage` (`ImageID`, `ProductID`, `ImageURL`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 'https://i.ibb.co/ZYW3VTp/brown-brim.png', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 'https://i.ibb.co/ypkgK0X/blue-beanie.png', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Review`
--

CREATE TABLE `Review` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Rating` decimal(2,1) NOT NULL,
  `Comment` text,
  `Date` date NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Review`
--

INSERT INTO `Review` (`ReviewID`, `UserID`, `ProductID`, `Rating`, `Comment`, `Date`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 1, '4.5', 'Great product!', '2024-02-17', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 2, '3.0', 'Could be better.', '2024-02-18', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Seller`
--

CREATE TABLE `Seller` (
  `SellerID` int(11) NOT NULL,
  `SellerName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Seller`
--

INSERT INTO `Seller` (`SellerID`, `SellerName`, `Email`, `Password`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'Seller1', 'seller1@example.com', 'password1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 'Seller2', 'seller2@example.com', 'password2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Transaction`
--

CREATE TABLE `Transaction` (
  `TransactionID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Date` date NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`UserID`, `Username`, `Email`, `Password`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'User1', 'user1@example.com', 'password1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 'User2', 'user2@example.com', 'password2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2),
(3, 'Agency', 'admin@gmail.com', '123456', '2024-03-22 19:36:45', NULL, '2024-03-22 19:36:45', NULL),
(4, 'SuperAdmin Account', 'admin@admin.com', '123456', '2024-03-29 19:47:02', NULL, '2024-03-29 19:47:02', NULL),
(5, 'SuperAdmin Request', 'admin@admin1.com', '123456', '2024-03-29 20:09:56', NULL, '2024-03-29 20:09:56', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Address`
--
ALTER TABLE `Address`
  ADD PRIMARY KEY (`AddressID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`CategoryID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Order`
--
ALTER TABLE `Order`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD PRIMARY KEY (`OrderDetailID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`),
  ADD KEY `orderdetail_ibfk_1` (`OrderID`),
  ADD KEY `orderdetail_ibfk_2` (`ProductID`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `SellerID` (`SellerID`),
  ADD KEY `CategoryID` (`CategoryID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `ProductImage`
--
ALTER TABLE `ProductImage`
  ADD PRIMARY KEY (`ImageID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Review`
--
ALTER TABLE `Review`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Seller`
--
ALTER TABLE `Seller`
  ADD PRIMARY KEY (`SellerID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Address`
--
ALTER TABLE `Address`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Category`
--
ALTER TABLE `Category`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `Order`
--
ALTER TABLE `Order`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  MODIFY `OrderDetailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `Product`
--
ALTER TABLE `Product`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Address`
--
ALTER TABLE `Address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `address_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `address_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Category`
--
ALTER TABLE `Category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `category_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Order`
--
ALTER TABLE `Order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `order_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `Order` (`OrderID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `orderdetail_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `orderdetail_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Product`
--
ALTER TABLE `Product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`SellerID`) REFERENCES `Seller` (`SellerID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`CategoryID`) REFERENCES `Category` (`CategoryID`),
  ADD CONSTRAINT `product_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `product_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `ProductImage`
--
ALTER TABLE `ProductImage`
  ADD CONSTRAINT `productimage_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`),
  ADD CONSTRAINT `productimage_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `productimage_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Review`
--
ALTER TABLE `Review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`),
  ADD CONSTRAINT `review_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `review_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Seller`
--
ALTER TABLE `Seller`
  ADD CONSTRAINT `seller_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `seller_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`OrderID`) REFERENCES `Order` (`OrderID`),
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
