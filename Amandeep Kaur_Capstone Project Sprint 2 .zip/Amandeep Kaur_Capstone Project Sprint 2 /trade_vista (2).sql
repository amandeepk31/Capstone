-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 01, 2024 at 10:00 PM
-- Server version: 5.7.38
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trade_vista`
--

-- --------------------------------------------------------

--
-- Table structure for table `Address`
--

CREATE TABLE `Address` (
  `AddressID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Street` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `ZipCode` varchar(10) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Address`
--

INSERT INTO `Address` (`AddressID`, `UserID`, `Street`, `City`, `State`, `ZipCode`, `Country`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 'Street1', 'City1', 'State1', '12345', 'Country1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 'Street2', 'City2', 'State2', '23456', 'Country2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Category`
--

CREATE TABLE `Category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Category`
--

INSERT INTO `Category` (`CategoryID`, `CategoryName`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'hats', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 'jackets', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2),
(3, 'sneakers', '2024-03-01 20:54:42', 3, '2024-03-01 20:54:42', 3),
(4, 'womens', '2024-03-01 20:54:42', 4, '2024-03-01 20:54:42', 4),
(5, 'mens', '2024-03-01 20:54:42', 5, '2024-03-01 20:54:42', 5);

-- --------------------------------------------------------

--
-- Table structure for table `Order`
--

CREATE TABLE `Order` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Status` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Order`
--

INSERT INTO `Order` (`OrderID`, `UserID`, `Status`, `Date`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 'Pending', '2024-02-17', '2024-03-01 21:56:43', 1, '2024-03-01 21:56:43', 1),
(2, 2, 'Shipped', '2024-02-18', '2024-03-01 21:56:43', 1, '2024-03-01 21:56:43', 1),
(3, 3, 'Delivered', '2024-02-19', '2024-03-01 21:56:43', 1, '2024-03-01 21:56:43', 1);

-- --------------------------------------------------------

--
-- Table structure for table `OrderDetail`
--

CREATE TABLE `OrderDetail` (
  `OrderDetailID` int(11) NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `ProductID` int(11) NOT NULL,
  `SellerID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Description` text,
  `Price` decimal(10,2) NOT NULL,
  `Stock` int(11) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`ProductID`, `SellerID`, `CategoryID`, `ProductName`, `Description`, `Price`, `Stock`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 1, 'Brown Brim', 'Description1', '25.00', 50, '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 1, 1, 'Blue Beanie', 'Description2', '18.00', 30, '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `ProductImage`
--

CREATE TABLE `ProductImage` (
  `ImageID` int(11) NOT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `ImageURL` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductImage`
--

INSERT INTO `ProductImage` (`ImageID`, `ProductID`, `ImageURL`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 'https://i.ibb.co/ZYW3VTp/brown-brim.png', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 'https://i.ibb.co/ypkgK0X/blue-beanie.png', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Review`
--

CREATE TABLE `Review` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Rating` decimal(2,1) NOT NULL,
  `Comment` text,
  `Date` date NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Review`
--

INSERT INTO `Review` (`ReviewID`, `UserID`, `ProductID`, `Rating`, `Comment`, `Date`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 1, 1, '4.5', 'Great product!', '2024-02-17', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 2, 2, '3.0', 'Could be better.', '2024-02-18', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Seller`
--

CREATE TABLE `Seller` (
  `SellerID` int(11) NOT NULL,
  `SellerName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Seller`
--

INSERT INTO `Seller` (`SellerID`, `SellerName`, `Email`, `Password`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'Seller1', 'seller1@example.com', 'password1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 'Seller2', 'seller2@example.com', 'password2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Transaction`
--

CREATE TABLE `Transaction` (
  `TransactionID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Date` date NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) DEFAULT NULL,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifiedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`UserID`, `Username`, `Email`, `Password`, `CreatedDate`, `CreatedBy`, `ModifiedDate`, `ModifiedBy`) VALUES
(1, 'User1', 'user1@example.com', 'password1', '2024-03-01 20:54:42', 1, '2024-03-01 20:54:42', 1),
(2, 'User2', 'user2@example.com', 'password2', '2024-03-01 20:54:42', 2, '2024-03-01 20:54:42', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Address`
--
ALTER TABLE `Address`
  ADD PRIMARY KEY (`AddressID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`CategoryID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Order`
--
ALTER TABLE `Order`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD PRIMARY KEY (`OrderDetailID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `SellerID` (`SellerID`),
  ADD KEY `CategoryID` (`CategoryID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `ProductImage`
--
ALTER TABLE `ProductImage`
  ADD PRIMARY KEY (`ImageID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Review`
--
ALTER TABLE `Review`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Seller`
--
ALTER TABLE `Seller`
  ADD PRIMARY KEY (`SellerID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `ModifiedBy` (`ModifiedBy`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Address`
--
ALTER TABLE `Address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `address_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `address_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Category`
--
ALTER TABLE `Category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `category_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Order`
--
ALTER TABLE `Order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `order_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `Order` (`OrderID`),
  ADD CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`),
  ADD CONSTRAINT `orderdetail_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `orderdetail_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Product`
--
ALTER TABLE `Product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`SellerID`) REFERENCES `Seller` (`SellerID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`CategoryID`) REFERENCES `Category` (`CategoryID`),
  ADD CONSTRAINT `product_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `product_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `ProductImage`
--
ALTER TABLE `ProductImage`
  ADD CONSTRAINT `productimage_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`),
  ADD CONSTRAINT `productimage_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `productimage_ibfk_3` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Review`
--
ALTER TABLE `Review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `Product` (`ProductID`),
  ADD CONSTRAINT `review_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `review_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Seller`
--
ALTER TABLE `Seller`
  ADD CONSTRAINT `seller_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `seller_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`OrderID`) REFERENCES `Order` (`OrderID`),
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`ModifiedBy`) REFERENCES `User` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
